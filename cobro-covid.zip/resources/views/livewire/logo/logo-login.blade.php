<div>
    <img src="{{ asset($logo) }}" alt="Logo de la empresa" width="128px">
</div>