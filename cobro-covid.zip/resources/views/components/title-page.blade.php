<div class="h-32 p-10 border-b border-gray-300" style="background-image:url({{asset('/img/fondos/header-blue.jpg')}});background-size: cover;">
    <h3 class="text-2xl text-white">{{$slot}}</h3>
</div>