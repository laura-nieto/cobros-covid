<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">

    <?php echo \Livewire\Livewire::styles(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('logo.colors')->html();
} elseif ($_instance->childHasBeenRendered('3t2rRXS')) {
    $componentId = $_instance->getRenderedChildComponentId('3t2rRXS');
    $componentTag = $_instance->getRenderedChildComponentTagName('3t2rRXS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3t2rRXS');
} else {
    $response = \Livewire\Livewire::mount('logo.colors');
    $html = $response->html();
    $_instance->logRenderedChild('3t2rRXS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <!-- ICON -->
    <link rel="shortcut icon" href="<?php echo e(asset('img/logo/SAIH-logo.png')); ?>"/>
</head>

<body class="antialiased" style="background-color:#B7E3F5;">
    <div class="min-h-screen">
        <head>
            <nav class="bg-white shadow-lg">
                <div class="md:flex items-center justify-between py-2 px-8 md:px-12">
                    <div class="flex justify-between items-center">
                        <div class="text-2xl font-bold text-gray-800 md:text-3xl">
                            <a href="/"><img src="<?php echo e(asset('/img/logo/SAIH-logo.png')); ?>" alt="" class="w-14"></a>
                        </div>
                        <div class="md:hidden">
                            <button type="button"
                                class="block text-gray-800 hover:text-gray-700 focus:text-gray-700 focus:outline-none">
                                <svg class="h-6 w-6 fill-current" viewBox="0 0 24 24">
                                    <path class="hidden"
                                        d="M16.24 14.83a1 1 0 0 1-1.41 1.41L12 13.41l-2.83 2.83a1 1 0 0 1-1.41-1.41L10.59 12 7.76 9.17a1 1 0 0 1 1.41-1.41L12 10.59l2.83-2.83a1 1 0 0 1 1.41 1.41L13.41 12l2.83 2.83z" />
                                    <path
                                        d="M4 5h16a1 1 0 0 1 0 2H4a1 1 0 1 1 0-2zm0 6h16a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2zm0 6h16a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2z" />
                                </svg>
                            </button>
                        </div>
                    </div>
                    <div class="flex flex-col md:flex-row hidden md:block -mx-2">
                        <a href="/"
                            class="text-gray-800 rounded hover:bg-gray-900 hover:text-gray-100 hover:font-medium py-2 px-2 md:mx-2">Inicio</a>
                        <a href="#"
                            class="text-gray-800 rounded hover:bg-gray-900 hover:text-gray-100 hover:font-medium py-2 px-2 md:mx-2">Contactanos</a>
                    </div>
                </div>
            </nav>
        </head>
        <main>
            <div class="container mx-auto pt-4">
                <?php echo e($slot); ?>

            </div>
        </main>
        <footer class="border-t bg-white text-gray-700 font-light text-sm px-3 py-2 w-full absolute bottom-0">
            <div class="flex flex-col-reverse sm:flex-row justify-between">
                <p class="leading-8 tracking-wide">
                    &copy; Copyright 2022. Todos los derechos reservados.
                </p>
                <?php if(Route::has('login')): ?>
                    <div class="sm:px-6 flex justify-center items-center">
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(url('/dashboard')); ?>"
                                class="text-sm text-gray-700 dark:text-gray-500 underline">Dashboard</a>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>"
                                class="text-sm text-gray-700 dark:text-gray-500 underline">Log in</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </footer>
    </div>

    <?php echo $__env->yieldContent('js'); ?>
</body>

</html><?php /**PATH C:\Users\Laura\Documents\Proyectos\cobro-covid\resources\views/layouts/guest.blade.php ENDPATH**/ ?>