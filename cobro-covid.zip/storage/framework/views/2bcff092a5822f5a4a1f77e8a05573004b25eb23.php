<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="shadow overflow-hidden sm:rounded-md">
        <div class="px-4 py-5 bg-white sm:p-6">
            <div class="mb-6">
                <h3 class="text-xl font-medium">Pago</h3>
            </div>
            <div>
                <h4 class="text-lg">Turno para el día <?php echo e($dia); ?> a las <?php echo e($hora); ?>hs. En <strong><?php echo e($sucursal->nombre); ?></strong> (<?php echo e($sucursal->direccion); ?>)</h4>
            </div>
            <div>
                <h4 class="text-lg">Total a pagar: $<?php echo e($servicio->precio); ?></h4>
            </div>
            <div class="px-4 py-3 text-right sm:px-6 bg-white">
                <a href="<?php echo e(url('pago/cortesia')); ?>" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-base font-medium rounded-md text-white bg-blue-500 hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-400">
                    Cortesía
                </a>
                <a href="<?php echo e(url('paypal/checkout')); ?>" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-base font-medium rounded-md text-white bg-blue-500 hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-400">
                  Pagar
                </a>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?><?php /**PATH C:\Users\Laura\Documents\Proyectos\cobro-covid\resources\views/reservar/forma_pago.blade.php ENDPATH**/ ?>