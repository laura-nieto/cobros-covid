<div class="h-32 p-10 border-b border-gray-300" style="background-image:url(<?php echo e(asset('/img/fondos/header-blue.jpg')); ?>);background-size: cover;">
    <h3 class="text-2xl text-white"><?php echo e($slot); ?></h3>
</div><?php /**PATH C:\Users\Laura\Documents\Proyectos\cobro-covid\resources\views/components/title-page.blade.php ENDPATH**/ ?>