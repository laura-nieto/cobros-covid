<div class="flex flex-col">
    <div class="-my-2 overflow-x-auto">
        <div class="pb-6 pt-3 align-middle inline-block min-w-full">
            <?php echo e($slot); ?>

        </div>
    </div>
</div><?php /**PATH C:\Users\Laura\Documents\Proyectos\cobro-covid\resources\views/components/seccion.blade.php ENDPATH**/ ?>