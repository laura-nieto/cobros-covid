<div class="w-full">
    <div class="py-12 flex-1 px-2 md:px-10">
         <?php $__env->slot('header', null, []); ?> 
            <?php echo e(__('Calendario')); ?>

         <?php $__env->endSlot(); ?>
        <?php if(session('success')): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.success','data' => []]); ?>
<?php $component->withName('success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?><?php echo e(session('success')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.seccion','data' => []]); ?>
<?php $component->withName('seccion'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <div>
                <div class="flex flex-col">
                    <label class="mb-2 mt-5 font-semibold text-gray-700" for="search">Citas para el día</label>
                    <input type="date" name="search" id="search" placeholder="Ingrese un día"
                        class="bg-white border border-gray-200 rounded shadow-sm w-96 <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="search">
                </div>
                <div class="mt-3">
                    <?php if(!$citas->count()): ?>
                        <h4 class="mt-5 text-xl font-bold">No hay citas para ese día</h4>
                    <?php else: ?>
                        <div class="flex bg-white text-black py-3">
                            <div class="border-gray-400 divide-y divide-gray-300 w-full lg:w-1/2">
                                <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora => $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex">
                                        <h5 class="p-4 cursor-pointer font-bold">
                                            <?php echo e(Carbon\Carbon::parse($hora)->format('H:i')); ?>

                                        </h5>
                                        
                                        <ol class="divide-y divide-gray-300 list-inside w-full">
                                            <?php $__currentLoopData = $cita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                                <li class="p-4 hover:bg-gray-50 cursor-pointer grid grid-cols-2">
                                                    <p><?php echo e($item->paciente->apellido . ' ' . $item->paciente->nombre); ?></p>
                                                    <a href="<?php echo e(url('paciente/'.$item->paciente->id)); ?>" class="justify-self-center px-4 py-2 bg-green-500 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition">Ver</a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ol>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\Laura\Documents\Proyectos\cobro-covid\resources\views/livewire/calendario.blade.php ENDPATH**/ ?>