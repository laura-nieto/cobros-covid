<div>
    <img src="<?php echo e(asset($logo)); ?>" alt="Logo de la empresa" width="64px" class="block w-14">
</div>
<?php /**PATH C:\Users\Laura\Documents\Proyectos\cobro-covid\resources\views/livewire/logo/logo-index.blade.php ENDPATH**/ ?>