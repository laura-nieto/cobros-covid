<style>
    .bg-nav{
        background-color: <?php echo e($fondo1); ?>;
    }
    .bg-main{
        background-color: <?php echo e($fondo2); ?>;
    }
    .color-nav{
        color:<?php echo e($color1); ?>!important;
    }
    .color-main{
        color:<?php echo e($color2); ?>;
    }
</style><?php /**PATH C:\Users\Laura\Documents\Proyectos\cobro-covid\resources\views/livewire/logo/colors.blade.php ENDPATH**/ ?>