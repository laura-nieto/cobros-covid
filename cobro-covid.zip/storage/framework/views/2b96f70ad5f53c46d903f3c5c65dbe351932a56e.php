<div class="w-full">
    <div class="py-12 flex-1 px-2 md:px-10">
         <?php $__env->slot('header', null, []); ?> 
            <?php echo e(__('Información del Paciente')); ?>

         <?php $__env->endSlot(); ?>
        <?php if(session('success')): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.success','data' => []]); ?>
<?php $component->withName('success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?><?php echo e(session('success')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.seccion','data' => []]); ?>
<?php $component->withName('seccion'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <?php if($modal): ?>
                <?php echo $__env->make('livewire.pacientes.modal-paciente-modificar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <div class="bg-white shadow overflow-hidden sm:rounded-lg px-4 py-5 sm:px-6">
                <div>
                    <dl>
                      <div class="px-4 py-5 md:grid md:grid-cols-2 hover:bg-gray-50 md:space-y-0 space-y-1 p-4 border-b">
                        <dt class="text-sm font-medium text-gray-500 text-lg">
                          Apellido
                        </dt>
                        <dd class="mt-1 text-sm text-gray-900 text-lg">
                            <?php echo e($paciente->apellido); ?>

                        </dd>
                      </div>
                      <div class="px-4 py-5 md:grid md:grid-cols-2 hover:bg-gray-50 md:space-y-0 space-y-1 p-4 border-b">
                        <dt class="text-sm font-medium text-gray-500 text-lg">
                          Nombre
                        </dt>
                        <dd class="mt-1 text-sm text-gray-900 text-lg">
                            <?php echo e($paciente->nombre); ?>

                        </dd>
                      </div>
                      <div class="px-4 py-5 md:grid md:grid-cols-2 hover:bg-gray-50 md:space-y-0 space-y-1 p-4 border-b">
                        <dt class="text-sm font-medium text-gray-500 text-lg">
                          Sexo
                        </dt>
                        <dd class="mt-1 text-sm text-gray-900 capitalize text-lg">
                            <?php echo e($paciente->sexo); ?>

                        </dd>
                      </div>
                      <div class="px-4 py-5 md:grid md:grid-cols-2 hover:bg-gray-50 md:space-y-0 space-y-1 p-4 border-b">
                        <dt class="text-sm font-medium text-gray-500 text-lg">
                          Fecha de Nacimiento
                        </dt>
                        <dd class="mt-1 text-sm text-gray-900 text-lg">
                            <?php echo e(Carbon\Carbon::parse($paciente->fecha_nacimiento)->format('d-m-Y')); ?>

                        </dd>
                      </div>
                      <div class="px-4 py-5 md:grid md:grid-cols-2 hover:bg-gray-50 md:space-y-0 space-y-1 p-4 border-b">
                        <dt class="text-sm font-medium text-gray-500 text-lg">
                          Teléfono
                        </dt>
                        <dd class="mt-1 text-sm text-gray-900 text-lg">
                            <?php echo e($paciente->telefono); ?>

                        </dd>
                      </div>
                      <div class="px-4 py-5 md:grid md:grid-cols-2 hover:bg-gray-50 md:space-y-0 space-y-1 p-4 border-b">
                        <dt class="text-sm font-medium text-gray-500 text-lg">
                          Correo Electrónico
                        </dt>
                        <dd class="mt-1 text-sm text-gray-900 text-lg">
                            <?php echo e($paciente->email); ?>

                        </dd>
                      </div>
                    </dl>
                </div>
                <div class="px-6 mt-6 flex justify-end">
                    <button wire:click='abrirModal()'
                    class="px-4 py-2 mr-2 bg-blue-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition">Editar</button>
                    <button
                    class="px-4 py-2 bg-green-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition">Validar</button>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\Laura\Documents\Proyectos\cobro-covid\resources\views/livewire/pacientes/paciente-vista.blade.php ENDPATH**/ ?>