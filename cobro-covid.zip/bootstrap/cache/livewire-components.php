<?php return array (
  'calendario' => 'App\\Http\\Livewire\\Calendario',
  'cortesia' => 'App\\Http\\Livewire\\Cortesia',
  'crud-servicios' => 'App\\Http\\Livewire\\CrudServicios',
  'crud-sucursales' => 'App\\Http\\Livewire\\CrudSucursales',
  'crud-user' => 'App\\Http\\Livewire\\CrudUser',
  'logo.colors' => 'App\\Http\\Livewire\\Logo\\Colors',
  'logo.crud-settings' => 'App\\Http\\Livewire\\Logo\\CrudSettings',
  'logo.logo-index' => 'App\\Http\\Livewire\\Logo\\LogoIndex',
  'logo.logo-login' => 'App\\Http\\Livewire\\Logo\\LogoLogin',
  'paciente.paciente-resultado' => 'App\\Http\\Livewire\\Paciente\\PacienteResultado',
  'paciente.paciente-vista' => 'App\\Http\\Livewire\\Paciente\\PacienteVista',
);